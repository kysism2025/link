^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_manipulator_teleop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.2 (2021-06-21)
------------------
* Noetic support
* Contributors: Will Son

2.0.1 (2019-02-18)
------------------
* none

2.0.0 (2019-02-08)
------------------
* added new package for teleoperation
* added teleop launch
* updated the CHANGELOG and version to release binary packages
* Contributors: Darby Lim, Hye-Jong KIM, Yong-Ho Na, Guilherme de Campos Affonso, Pyo
