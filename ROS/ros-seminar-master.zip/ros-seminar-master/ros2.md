# ROS 2 

## Why ROS 2?
- [ROS 2 Brochure](https://github.com/ros2/ros2_documentation/blob/master/source/Marketing/ros2-brochure-a4-web.pdf)
- [ROS 2 Overview](https://index.ros.org/doc/ros2/)
